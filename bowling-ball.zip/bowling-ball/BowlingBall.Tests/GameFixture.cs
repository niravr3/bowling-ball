﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BowlingBall.Tests
{
    [TestClass]
    public class GameFixture
    {
        private Game g;

        public GameFixture()
        {
            g = new Game();
        }

        private void rollMany(int rolls, int pins)
        {
            for (int i = 0; i < rolls; i++)
            {
                g.Roll(pins);
            }
        }

        private void rollSpare()
        {
            g.Roll(6);
            g.Roll(4);
        }

        [TestMethod]
        public void TestGutterGame()
        {
            rollMany(20, 0);
            Assert.AreEqual(0, g.GetScore());
        }

        [TestMethod]
        public void TestAllOnes()
        {
            rollMany(20, 1);
            Assert.AreEqual(20, g.GetScore());
        }

        [TestMethod]
        public void TestOneSpare()
        {
            rollSpare();
            g.Roll(4);
            rollMany(17, 0);
            Assert.AreEqual(18, g.GetScore());
        }

        [TestMethod]
        public void TestOneStrike()
        {
            g.Roll(10);
            g.Roll(4);
            g.Roll(5);
            rollMany(17, 0);
            Assert.AreEqual(28, g.GetScore());
        }

        [TestMethod]
        public void TestPerfectGame()
        {
            rollMany(12, 10);
            Assert.AreEqual(300, g.GetScore());
        }

        [TestMethod]
        public void TestRandomGameNoExtraRoll()
        {
            g.Roll(new int[] { 1, 3, 7, 3, 10, 1, 7, 5, 2, 5, 3, 8, 2, 8, 2, 10, 9, 0 });
            Assert.AreEqual(131, g.GetScore());
        }

        [TestMethod]
        public void TestRandomGameWithSpareThenStrikeAtEnd()
        {
            g.Roll(new int[] { 1, 3, 7, 3, 10, 1, 7, 5, 2, 5, 3, 8, 2, 8, 2, 10, 9, 1, 10 });
            Assert.AreEqual(143, g.GetScore());
        }

        [TestMethod]
        public void TestRandomGameWithThreeStrikesAtEnd()
        {
            g.Roll(new int[] { 1, 3, 7, 3, 10, 1, 7, 5, 2, 5, 3, 8, 2, 8, 2, 10, 10, 10, 10 });
            Assert.AreEqual(163, g.GetScore());
        }
    }
}
