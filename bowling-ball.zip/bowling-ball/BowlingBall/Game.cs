﻿namespace BowlingBall
{
    public class Game
    {
        private int[] rollsArray = new int[21];
        int currentRollCount = 0;
       
        /// <summary>
        /// Perform roll based on given pins.
        /// </summary>
        /// <param name="pins">Number of pins.</param>
        public void Roll(int pins)
        {
            rollsArray[currentRollCount++] = pins;
        }

        /// <summary>
        /// Performs roll.
        /// </summary>
        /// <param name="pins">Pins array</param>
        public void Roll(int[] pins)
        {
            for (int i = 0; i < pins.Length; i++)
            {
                rollsArray[currentRollCount++] = pins[i];
            }
        }

        /// <summary>
        /// Return final score.
        /// </summary>
        /// <returns>Score</returns>
        public int GetScore()
        {
            int score = 0;
            int index = 0;
            for (int frame = 0; frame < 10; frame++)
            {
                if (Spare(index))
                {
                    score += 10 + rollsArray[index + 2];
                    index += 2;
                }
                else if (Strike(index))
                {
                    score += 10 + rollsArray[index + 1] + rollsArray[index + 2];
                    index++;
                }
                else
                {
                    score += rollsArray[index] + rollsArray[index + 1];
                    index += 2;
                }

            }

            return score;
        }

        /// <summary>
        /// Checks spare or not.
        /// </summary>
        /// <param name="index">Index</param>
        /// <returns>True or false</returns>
        private bool Spare(int index)
        {
            return rollsArray[index] + rollsArray[index + 1] == 10;
        }

        /// <summary>
        /// Checks strike or not.
        /// </summary>
        /// <param name="index">Index</param>
        /// <returns>True or false</returns>
        private bool Strike(int index)
        {
            return rollsArray[index] == 10;
        }
    }
}
